#!/bin/bash

java -jar jsfapp.jar
